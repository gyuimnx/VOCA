import React, { useState, useEffect } from "react";
import "./Quiz.css";
import { Link } from "react-router-dom";

function Quiz() {
    const [bringChapters, setBringChapters] = useState([]); //로컬스토리지에서 불러온 챕터들
    const [selectedChapter, setSelectedChapter] = useState(null); //선택한 챕터

    const [quizWord, setQuizWord] = useState([]); //퀴즈에 사용할 단어
    const [currentWordIndex, setCurrentWordIndex] = useState(0); //현재 문제 인덱스
    const [answer, setAnswer] = useState(""); //입력한 답
    const [quizStart, setQuizStart] = useState(false); //퀴즈 시작했는가?
    const [score, setScore] = useState(0); //총 정답
    const [wrong, setWrong] = useState(0); //총 오답

    //게임 시작 함수. shuffleArray에 선택한 챕터의 단어를 랜덤으로 배치시켜서 저장
    const startQuiz = () => {
        //null이 아니고 단어 길이가 1이상이면 실행
        if (selectedChapter && selectedChapter.words.length > 0) {
            const shuffleArray = [...selectedChapter.words].sort(() => Math.random() - 0.5);
            setQuizWord(shuffleArray);
            setCurrentWordIndex(0);
            setQuizStart(true);
            setScore(0);
            setWrong(0);
        };
    };

    //답변 제출 함수
    const handleSubmitAnswer = (e) => {
        e.preventDefault();

        // 정답 확인 (대소문자 무시)
        if (answer.trim().toLowerCase() === quizWord[currentWordIndex].word.toLowerCase()) {
            setScore(prevScore => prevScore + 1);
        } else {
            setWrong(prevWrong => prevWrong + 1);
        }

        if (currentWordIndex < quizWord.length - 1) { //다음 문제로 이동
            setCurrentWordIndex(prevIndex => prevIndex + 1);
        } else {
            setQuizStart(false); //퀴즈 종료
        }
        setAnswer(''); //입력 초기화
    };

    //스토리지에서 챕터 불러오기
    useEffect(() => {
        const storedChapters = JSON.parse(localStorage.getItem('chapters')) || [];
        setBringChapters(storedChapters);
    }, []);

    //챕터 선택 함수
    const handleChapterSelect = (chapter) => {
        setSelectedChapter(chapter);
    };

    return (
        <div className="Quiz_container">
            <div className="Quiz">
                {!quizStart ? (
                    <div>
                        <h2>챕터 선택</h2>
                        {bringChapters.length === 0 ? (<p>생성된 챕터가 없습니다.</p>) : (
                            <div className="ChapterList_Q">
                                {bringChapters.map((bringChapter, index) => (
                                    <div key={index}
                                        className={`QuizChapterItem ${selectedChapter === bringChapter ? 'selected' : ''} ${bringChapter.words.length === 0 ? 'disabled' : ''
                                            }`}
                                        onClick={() => {
                                            if (bringChapter.words.length > 0) handleChapterSelect(bringChapter)
                                        }}>
                                        {bringChapter.name}
                                        <div>({bringChapter.words.length} 단어)</div>
                                    </div>
                                ))}
                            </div>
                        )}
                        <div className="startBtn_container">
                            <button
                                className="QuizStartBtn"
                                onClick={startQuiz}
                                disabled={!selectedChapter || selectedChapter.words.length === 0}
                            >{selectedChapter ? `${selectedChapter.name} : START` : "챕터를 선택하세요."}
                            </button>
                        </div>
                    </div>
                ) : (
                    <div className="QuizSection">
                        <button className="BackWord" onClick={() => setQuizStart(false)}>back</button>
                        <h1>[{selectedChapter.name}] Word Quiz</h1>
                        <div className="OX">
                            <span className="O">O</span> {score}
                            <span className="X">X</span> {wrong}
                        </div>
                        <div className="QuizQuestion">
                            <h2>다음 단어의 영어 표현은?</h2>
                            <h3 className="question">{quizWord[currentWordIndex].meaning}</h3>
                        </div>
                        <form className="formQuiz" onSubmit={handleSubmitAnswer}>
                            <input
                                className="inputWord" 
                                type="text"
                                value={answer}
                                onChange={(e) => setAnswer(e.target.value)}
                                placeholder="영어 단어를 입력하세요."
                            />
                            <button type="submit">제출</button>
                        </form>
                        {!quizStart && (
                            <div className="QuizResult">
                                <h3>퀴즈 종료</h3>
                                <p>최종 점수: {score} / {quizWord.length}</p>
                            </div>
                        )}
                    </div>
                )}
                <Link to={'/'}>
                    <button className="BackHome">Home</button>
                </Link>
            </div>
        </div>
    );
}

export default Quiz;